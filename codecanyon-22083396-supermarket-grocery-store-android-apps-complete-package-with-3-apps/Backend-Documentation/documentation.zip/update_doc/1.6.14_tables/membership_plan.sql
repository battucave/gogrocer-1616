-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 22, 2021 at 06:46 AM
-- Server version: 10.3.32-MariaDB-0ubuntu0.20.04.1
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin_newgogrocer`
--

-- --------------------------------------------------------

--
-- Table structure for table `membership_plan`
--

CREATE TABLE `membership_plan` (
  `plan_id` int(11) NOT NULL,
  `image` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plan_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `free_delivery` int(11) NOT NULL DEFAULT 0,
  `reward` int(11) NOT NULL DEFAULT 0,
  `instant_delivery` int(11) NOT NULL DEFAULT 0,
  `plan_description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `days` int(11) NOT NULL DEFAULT 0,
  `price` int(11) NOT NULL,
  `hide` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `membership_plan`
--

INSERT INTO `membership_plan` (`plan_id`, `image`, `plan_name`, `free_delivery`, `reward`, `instant_delivery`, `plan_description`, `days`, `price`, `hide`) VALUES
(1, '/images/coupon/2021-11-16/3d156563ec9bea6830340cb3dfeb6212.jpg', 'ffrfr', 1, 2, 1, '<h2 style=\"text-align:center\"><strong>Benefits of this&nbsp;membership plan</strong></h2>\r\n\r\n<ul>\r\n	<li><strong>Get 2x rewards points&nbsp;</strong><strong>for 30 days</strong><br />\r\n	you will be able to get 2x rewards point then a normal user if your cart value matches the crieteria.</li>\r\n	<li><strong>Get Instant Delivery for 30 days</strong><br />\r\n	you will be able to get instant/same day delivery</li>\r\n	<li><strong>Get free Delivery&nbsp;for 30 days</strong><br />\r\n	you will be able to get free delivery on any order</li>\r\n</ul>', 30, 100, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `membership_plan`
--
ALTER TABLE `membership_plan`
  ADD PRIMARY KEY (`plan_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `membership_plan`
--
ALTER TABLE `membership_plan`
  MODIFY `plan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
